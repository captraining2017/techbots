# Load libraries
import pandas
import numpy as np
from pandas.tools.plotting import scatter_matrix
import matplotlib.pyplot as plt
from sklearn import model_selection
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC

# Load dataset
#url = "D:\\mycode\\python\\machine_learning\\iris.data"
#url = "iris.data"
#names = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']
#dataset = pandas.read_csv(url, names=names)

# class distribution
#print(dataset.groupby('class').size())

#np.random.seed(0)
startdate='2016-01-01';
enddate='2017-03-31';
pandas.to_datetime(startdate)
x=pandas.to_datetime(enddate)-pandas.to_datetime(startdate)
samplingRate=(1/x.total_seconds())*1000
# print(1/x.total_seconds())
# print('{0:.20f}'.format(samplingRate) )
# print(str(samplingRate)+'')
rng = pandas.date_range(startdate,'2017-03-31',freq=str('{0:.20f}'.format(samplingRate))+'S')
# rng = pandas.date_range(startdate,'2017-03-31',freq='80000ms')
cusid=np.random.random_integers(1,100,rng.size)
print(cusid);
amount = np.random.random_integers(2500,5000000,rng.size)
print(amount);
txstatus = np.random.random_integers(0,1,rng.size)
print(txstatus);
columns=['CustomerID','Amount','Date','status'];
#df_=pandas.DataFrame(cusid,amount,rng,txstatus,columns=columns);
#df = pandas.DataFrame({ 'CustomerID': np.random.random_integers(1,100),'Amount': np.random.random_integers(2500,5000000),'Date': pandas.date_range('2016-01-01','2017-03-31',freq='80000ms'), 'status': np.random.random_integers(0,1) })
df = pandas.DataFrame({ 'CustomerID': cusid,'Amount': amount,'Date': rng, 'status': txstatus })
# print(np.random.random_integers(2500,5000000))
df.to_csv('output.csv', index=False, header=True) 
#print(df)