# Load libraries
import pandas as pd
# from pandas.tools.plotting import scatter_matrix
# import matplotlib.pyplot as plt
# from sklearn import model_selection
# from sklearn.metrics import classification_report
# from sklearn.metrics import confusion_matrix
# from sklearn.metrics import accuracy_score
# from sklearn.linear_model import LogisticRegression
# from sklearn.tree import DecisionTreeClassifier
# from sklearn.neighbors import KNeighborsClassifier
# from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
# from sklearn.naive_bayes import GaussianNB
# from sklearn.svm import SVC
import numpy as np

# def salaryGen():
		# data = np.random.random_integers(100000,2000000,size=(3.,4.,3.){
		
		
		
		
		# }		




columns=['cust_id','cust_name','cust_salary']

data=np.random.binomial(500000, 0.3, size=None) 
df_=pd.DataFrame(data,index=['1','2','3'],columns=columns);
distribution=[];
for i in 100:
			if i<=30:
						distribution.push(0.3)
			else if i>30 and i<=70:
						distribution.push(0.4)
			else:
				distribution.push(0.3)
						
				
print(distribution);
#print(np.random.random_integers(100000,2000000,size=100);
print(np.random.choice(2000000, 100,  p=[0.3, 0.4, 0.3]));

